package org.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/hello")
public class MyController
{
	@RequestMapping(method = RequestMethod.POST)
	public org.springframework.web.servlet.ModelAndView myMessage(HttpServletRequest request,HttpServletResponse resp)
	{	//Login login=new Login();
		String user=request.getParameter("uname");
 		String pass=request.getParameter("password");
		if(pass.equals("1234") && user!=null)
		{
			return new ModelAndView("welcome","welcomemsg","Hello"+" "+user);
		}
		else
		{
			return new ModelAndView("welcome","welcomemsg","Error"+" "+user);
		}
	}  	
}

@Controller
@RequestMapping("/mymap")
class MyDemo
{
	@RequestMapping(method = RequestMethod.GET)
	   public String printHello() {
	      return "index";
	   }
}

@Controller
@RequestMapping("/hi")
class UserRegistration
{	
	@RequestMapping(method = RequestMethod.POST)
	public String mymsg(@ModelAttribute Register register,Model model)
	{
		model.addAttribute("register", register);
		return "result";
	}

}

@Controller
@RequestMapping("/reg")
class user
{
	@RequestMapping(method = RequestMethod.GET)
	public String demo()
	{
		//System.out.println("I'm here");
		return "register";
	}
}